/*
 * CommonsCode.java
 * Boilerplate Code that initializes many of the constants we use in the project
 * Defines colours, bounding spheres, appearance, and lights
 */

import javax.swing.JPanel;
import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

public class CommonsCode extends JPanel {

	private static final long serialVersionUID = 1L;	
	//Colour designations with Color3f
	public final static Color3f White = new Color3f(1.0f, 1.0f, 1.0f);
	public final static Color3f Red = new Color3f(1.0f, 0.0f, 0.0f);
	public final static Color3f Orange = new Color3f(1.0f, 0.6f, 0.0f);
	public final static Color3f Yellow = new Color3f(1.0f, 1.0f, 0.0f);
	public final static Color3f Green = new Color3f(0.0f, 1.0f, 0.0f);
	public final static Color3f Blue = new Color3f(0.0f, 0.0f, 1.0f);
	public final static Color3f Purple = new Color3f(0.5f, 0.0f, 0.5f);
	public final static Color3f Grey = new Color3f(0.35f, 0.35f, 0.35f);
	public final static Color3f Black = new Color3f(0.0f, 0.0f, 0.0f);
	public final static Color3f Magenta = new Color3f(1.0f, 0.0f, 1.0f);
	public final static Color3f Lime = new Color3f(0.0f, 1.0f, 0.5f);
	public final static Color3f Cyan = new Color3f(0.0f, 1.0f, 1.0f);

	//BoundingSpheres
	public final static BoundingSphere fourHBS = new BoundingSphere(new Point3d(), 400.0);
	public final static BoundingSphere twoHBS = new BoundingSphere(new Point3d(), 200.0);
	public final static BoundingSphere hundredBS = new BoundingSphere(new Point3d(), 100.0);
	public final static BoundingSphere twentyBS = new BoundingSphere(new Point3d(), 20.0);

	//set_Material returns a generic Material using the given colour
	public static Material set_Material(Color3f m_clr) {	//Takes in Color3f
		Material mtl = new Material();	//Create new material
		mtl.setShininess(128); 		//Set Shininess
		mtl.setAmbientColor(White);	//Set ambient colour
		mtl.setDiffuseColor(m_clr);	//Set diffusion colour
		mtl.setSpecularColor(Grey);	//Set specular colour
		mtl.setEmissiveColor(Black);//Set emissive colour (in this case, non-emissive)
		mtl.setLightingEnable(true);//Enable lighting
		return mtl;		//Return the finished material with all set aspects
	}

	//set_Appearance uses set_Material and a given colour, to return an appearance with the material that uses the colour
	public static Appearance set_Appearance(Color3f clr) {	//Takes in Color3f
		Appearance app = new Appearance();	//Create new appearance
		app.setMaterial(set_Material(clr)); // set appearance's material with the colour
		return app;		//Return the finished appearance with the material
	}

	//add_Lights creates lights that illuminate the space they're in, and returns them in a BranchGroup
	//It takes in a Color3f and can generate up to 2 coloured lights
	public static BranchGroup add_Lights(Color3f clr, int p_num) {	
		BranchGroup lightBG = new BranchGroup();  	// Create a new BranchGroup to hold lights
		Point3f atn = new Point3f(1f, 0.0f, 0.0f); 	// light attenuation - how it dissipates over distance
		PointLight ptLight;		//Create a PointLight object
		float adjt = 1f;		//Adjustment factor

		//Creates up to 2 lights depending on the p_num
		for (int i = 0; (i < p_num) && (i < 2); i++) {
			if (i > 0){
				adjt = -1f; // use 'adjt' to change light position
			}
			 // Create a new PointLight with the given color, position, and attenuation
			ptLight = new PointLight(clr, new Point3f(3.0f * adjt, 1.0f, 3.0f * adjt), atn);
			ptLight.setInfluencingBounds(fourHBS); // Set the region where the light affects objects
			lightBG.addChild(ptLight); // attach the point light to 'lightBG'
		}
		return lightBG;		// Return the BranchGroup containing the lights
	}

}
