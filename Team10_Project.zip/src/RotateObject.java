/*
 * RotateObject.java
 * Has functions that control and add continuous rotation
 * Allows for control of Alpha (both pause/resume and Alpha attributes)
 * 
 */

import org.jogamp.java3d.*;


class RotateObject {
	Boolean trans = true;	// For checking if there has already been a translation
	TransformGroup objTG;	//object TransformGroup, this is the object obtained by the constructor (and that is rotated)
	Transform3D translator;	//Transform3D that contains translations for the object
	int cycleTime; 	// cycleTime is the time in milliseconds for each rotation cycle
	char axis; 		// Axis refers to which axis we want to rotate on
	Alpha alpha;	//Alpha for our rotation, contains all the data for how our object rotates
	float rotationMin = 0f; // Minimum rotation for the object (minimum distance it can rotate for)
	float rotationMax = (float) Math.PI * 2; // Maximum rtation for the object (max distance it can rotate for)

	//Constructor that takes object TransformGroup, Transform3D for translations, cycle time, and the axis of rotation
	public RotateObject(TransformGroup objTG, Transform3D translator, int cycleTime, char axis) {
		this.objTG = objTG; 			// Get an objTG from parameters, we modify this to perform the rotation
		this.translator = translator; 	// Get the given translations
		this.cycleTime = cycleTime;		// Get the cycle time for the alpha
		this.axis = axis;				// Get the axis of rotation
		// Default alpha which only uses cycle time
		alpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, cycleTime, 0, 0, 0, 0, 0); 
	}

	//Extra constructor for objects without translations (doesn't take Transform3D)
	public RotateObject(TransformGroup objTG, int cycleTime, char axis) { // In case there aren't any translations applied
		this.objTG = objTG;
		this.cycleTime = cycleTime;
		this.axis = axis;
		trans = false;		//Update boolean, designates that it doesn't use any translations
		alpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, cycleTime, 0, 0, 0, 0, 0);
	}

	//setAlpha changes alpha to a new given alpha
	public void setAlpha(Alpha alpha) {
		this.alpha = alpha;
	}


	//PauseAlpha and ResumeAlpha perform their respective functions but from the RotateObject class (instead of alpha)
	public void PauseAlpha() { // Pause Alpha (rotation)
		alpha.pause();
	}
	public void ResumeAlpha() { // Resume Alpha (rotation)
		alpha.resume();
	}
	//IsPaused checks if the alpha is paused or not
	public boolean IsPaused() {
		return alpha.isPaused();
	}
	//switchAlpha toggles alpha between paused and unpaused
	public void switchAlpha() {
		if (IsPaused()) {	//if it's paused, resume the alpha
			ResumeAlpha();
		} else {	//otherwise pause alpha (if it's unpaused)
			PauseAlpha();
		}
	}

	public TransformGroup AddRotation() {
		// Create our rotationTG which also contains the translation (if there is one)
		TransformGroup rotationTG = (trans) ? new TransformGroup(translator) : new TransformGroup(); 
		objTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE); // Allow transformation (rotation)
		Transform3D rotAxis = new Transform3D(); // Rotation axis is naturally y
		RotationInterpolator rotateInterpol; 	// rotationInterpolator
		if (axis == 'z') { // If we want it to be z we need to change the axis
			rotAxis.rotZ(Math.PI / 2.0d); // rotating 90 degrees puts us on the z axis
			//also uses rotationMin and rotationMax to set how far it can rotate
			rotateInterpol = new RotationInterpolator(alpha, objTG, rotAxis, rotationMin, rotationMax); 
		} 
		else if (axis == 'x') { // Same as z but for x-axis
			rotAxis.rotX(Math.PI / 2.0d); // rotating 90 degrees puts us on the x axis
			rotateInterpol = new RotationInterpolator(alpha, objTG, rotAxis, rotationMin, rotationMax);
		} 
		else {
			//RotationInterpolators take an alpha, the object TransformGroup, rotation axis, and min/max for rotation
			//to actually cause the object to rotate (when added to a TransformGroup)
			rotateInterpol = new RotationInterpolator(alpha, objTG, rotAxis, rotationMin, rotationMax);
		}
		rotateInterpol.setSchedulingBounds(CommonsCode.twentyBS); // Set Scheduling Bounds
		rotationTG.addChild(objTG); 			// add objTG, which is the original object
		rotationTG.addChild(rotateInterpol); 	// add interpolator, containing the rotation behaviour
		return rotationTG; // Return rotating transformGroup with transformation (if there was one)
	}

}
