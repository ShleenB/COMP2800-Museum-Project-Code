/* 
 * ProjectCode.java
 * Primary code for the project, all other java files culminate here to create the Museum Simulator
 * The code here builds the environment of the Museum, activates mouse/keyboard interaction, creates movement,
 * creates walls/bounds, and allows for interaction. 
 * After creating all of the required aspects, ProjectCode's main function will actually run the Museum Simulator
 */

import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.*;
import java.awt.Font;
import java.awt.Color;

import org.jogamp.java3d.*;
import org.jogamp.java3d.utils.universe.SimpleUniverse;
import org.jogamp.java3d.utils.picking.*;
import org.jogamp.vecmath.*;

public class ProjectCode extends JPanel implements KeyListener, MouseMotionListener {

    //For JFrame
    private static final long serialVersionUID = 1L;
    private static JFrame frame;

    // Total Number of Objects in the Museum
    private static final int OBJ_NUM = 25;
    // Array of 3D Objects in the Museum
    private static BuildObjects[] object3D = new BuildObjects[OBJ_NUM];

    // For Key Pressing and Mouse Clicking Logic
    private boolean isDragging = false;
    private int prevMouseX, prevMouseY;

    // Museum Sounds & Music
    private static SoundUtilityJOAL soundPlayer = new SoundUtilityJOAL();   //Plays the sounds
    private static String[] soundNames = { "AdaLovelace", "AlanTuring", "Linux", "Storage", "Evolution", "Background" };    //All of the .wav files we use

    // Pick object let us seperately click on buttons to turn them on/off
    private static PickCanvas pick;
    private Canvas3D canvas3D; // also need for mouse picking

    // Character Variables (for vision and movement)
    private Vector3f position = new Vector3f(0f, 2.0f, 5f); // Starting position
    private float yaw = 0.0f; // Left-right rotation
    private float pitch = 0.0f; // Up-down rotation
    private String currentObject = null;    //Saves the currentObject we've clicked
    private TransformGroup viewTransformGroup;      //We use this to transform/move our viewpoint

    // Lists for our Added Walls and Interactive Object Zones
    private static List<BoundingBox> collisionObjects = new ArrayList<>();          //List of collidable objects, these act as walls and limit our movement to the museum areas
    private static Map<BoundingBox, String> interactiveObjects = new HashMap<>();   //List of interaction boxes (ie. when we get close to these, we get the interaction prompt)

    // JLabel allows us to display menu/prompts in 2D within the 3D environment
    private JLabel interactionLabel;

    /* a function to create the Museum and it's objects */
    private static TransformGroup create_Museum() {
        BuildObjects.create_Materials(); //Generating the materials used in object creation
        // Object Creation Variables
        TransformGroup MuseumTG = new TransformGroup();     //Primary transformGroup, this will contain ALL of the objects in our Museum, meaning all objects are added to it as children
        ObjectData objData;     //ObjectData is used repeatedly to initialize every object (that isn't a string)
        Alpha turingAlpha, fanAlpha, tuxAlpha, computerAlpha;   //Different alphas for each of the spinning objects

        // Sounds
        for (int i = 0; i < soundNames.length - 1; i++) {
            if (!soundPlayer.load(soundNames[i], 0, 0, 0, false)) {     //Load each of the sounds, these ones are the exhibit sounds so they don't repeat
                System.out.println("Could not load: " + soundNames[i]); // If it can't load
            }
        }
        soundPlayer.load(soundNames[5], 0, 0, 0, true);     //This is the only repeating sound, which is the background music
        soundPlayer.play(soundNames[5]);    //Playing the background music

        /**
         * To add an object, you only need to define it's data type, which contain all the necessary info to create the objects:
         * positionData - if you only want singular translation and rotation
         * rotatingPositionData - if you want singular translation, rotation, and continuous rotation
         * paintingData - Use with "Painting1" object name to create paintings with a custom frame and painting content
         * 
         * There are also colorStringData and morphingPaintingData, but those are used in the next section
         * 
         * After defining it's data type and filling in the object data, add it to the
         * object3D array and MuseumTG (with position_Object)
        */

        // Museum Structure
        // Museum
        objData = new positionData("MuseumRoom", 30.0d, new Vector3f(0, 2.5f, 0), new double[] { 0, 0, 0 });
        object3D[0] = new MuseumObject(objData);
        // Door
        objData = new positionData("door", 3.5d, new Vector3f(0f, 1.15f, 21.5f), new double[] { 0, Math.PI, 0 });
        object3D[1] = new MuseumObject(objData);

        // Alan Turing Exhibit
        // Plinth
        objData = new positionData("plinth1", 1.4d, new Vector3f(-14.5f, -0.8f, 4.0f), new double[] { 0, 0, 0 });
        object3D[2] = new MuseumObject(objData);
        // Turing Machine
        turingAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 4000, 0, 0, 0, 0, 0);
        objData = new rotatingPositionData("TuringMachine", 1.0d, new Vector3f(-14.5f, 1.1f, 4.0f),
                new double[] { 0, Math.PI / 2, 0 }, 'y', turingAlpha);
        object3D[3] = new MuseumObject(objData);
        // Alan Turing Painting
        objData = new paintingData("Painting1", 4.0d, new Vector3f(-14.5f, 3f, 2.35f),
                new double[] { 0, -Math.PI / 2, 0 }, "AlanTuring", "wood");
        object3D[4] = new MuseumObject(objData);

        // Ada Lovelace Exhibit
        // Slanted Plinth
        objData = new positionData("plint2", 1.4d, new Vector3f(14.5f, -0.8f, 4.0f),
                new double[] { 0, -Math.PI / 2, 0 });
        object3D[5] = new MuseumObject(objData);
        // Ada Poster
        objData = new positionData("Poster1", 1.0d, new Vector3f(14.5f, 1.0f, 4.0f),
                new double[] { -Math.PI / 1.5, -Math.PI, -Math.PI / 2 });
        object3D[6] = new MuseumObject(objData);
        // Ada Painting
        objData = new paintingData("Painting1", 4.0d, new Vector3f(14.5f, 3f, 2.35f),
                new double[] { 0, -Math.PI / 2, 0 }, "AdaLovelace", "wood");
        object3D[7] = new MuseumObject(objData);

        // Decorative Objects
        // Fan
        fanAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 4000, 0, 0, 0, 0, 0);
        objData = new rotatingPositionData("Fan", 2.5d, new Vector3f(0f, 5.8f, 4.0f), new double[] { 0, 0, 0 }, 'y',
                fanAlpha);
        object3D[8] = new MuseumObject(objData);

        // Pot1 1(Right/Left), 2(up/dpwn) and third(front/back) //Front Left
        objData = new positionData("BestPlant", 3.0d, new Vector3f(-27f, 0.70f, -19.0f), new double[] { 0, 0, 0 });
        object3D[9] = new MuseumObject(objData);

        // Pot2 // Back Left
        objData = new positionData("BestPlant", 3.0d, new Vector3f(27f, 0.70f, -19.0f), new double[] { 0, 0, 0 });
        object3D[10] = new MuseumObject(objData);

        // Pot3 //Front Right
        objData = new positionData("BestPlant", 3.0d, new Vector3f(-27f, 0.70f, 19.0f), new double[] { 0, 0, 0 });
        object3D[11] = new MuseumObject(objData);

        // Pot4 //Back Right
        objData = new positionData("BestPlant", 3.0d, new Vector3f(27f, 0.70f, 19.0f), new double[] { 0, 0, 0 });
        object3D[12] = new MuseumObject(objData);

        // Evolution of Computers Exhibit
        objData = new positionData("plinth1", 1.4d, new Vector3f(-0.25f, -0.8f, -20.0f), new double[] { 0, 0, 0 });
        object3D[13] = new MuseumObject(objData);

        objData = new positionData("EvlofComp3", 4d, new Vector3f(-0.25f, 1.8f, -20.0f), new double[] { 0, 0, 0 });
        object3D[14] = new MuseumObject(objData);

        objData = new paintingData("Painting1", 3.0d, new Vector3f(0, 4.0f, -21.5f),
                new double[] { -Math.PI / 2, -Math.PI, -Math.PI / 2 }, "EvolutionOfComputers", "wood");
        object3D[15] = new MuseumObject(objData);

        // Linux Exhibit
        objData = new paintingData("Painting1", 3.0d, new Vector3f(15.5f, 4.0f, -21.5f),
                new double[] { 0, -Math.PI / 2, 0 }, "Tuxfinal", "wood");
        object3D[16] = new MuseumObject(objData);

        tuxAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 4000, 0, 0, 0, 0, 0);
        objData = new rotatingPositionData("Tux", 1.0d, new Vector3f(15.5f, 1.8f, -20.0f),
                new double[] { 0, -Math.PI / 2, 0 }, 'y', tuxAlpha);
        object3D[17] = new MuseumObject(objData);

        objData = new positionData("plinth1", 1.4d, new Vector3f(15.5f, -0.8f, -20.0f), new double[] { 0, 0, 0 });
        object3D[18] = new MuseumObject(objData);

        // Storage Devices Exhibit
        computerAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE, 0, 0, 4000, 0, 0, 0, 0, 0);
        objData = new rotatingPositionData("CD", 1.0d, new Vector3f(-19.5f, 0.20f, -19.0f),
                new double[] { 0, -Math.PI / 2, 0 }, 'y', computerAlpha);
        object3D[19] = new MuseumObject(objData);

        objData = new rotatingPositionData("floppydisk1", 0.6d, new Vector3f(-16.5f, 0.20f, -19.0f),
                new double[] { 0, -Math.PI / 2, 0 }, 'y', computerAlpha);
        object3D[20] = new MuseumObject(objData);

        objData = new rotatingPositionData("USB", 1.0d, new Vector3f(-13.5f, 0.25f, -19.0f), new double[] { 0, 0, 0 },
                'y', computerAlpha);
        object3D[21] = new MuseumObject(objData);

        objData = new positionData("rtable", 4.4d, new Vector3f(-16.5f, -1.5f, -19.0f), new double[] { 0, 0, 0 });
        object3D[22] = new MuseumObject(objData);

        objData = new paintingData("Painting1", 3.0d, new Vector3f(-16.5f, 3.0f, -21.5f),
                new double[] { -Math.PI / 2, -Math.PI, -Math.PI / 2 }, "StorageDevice", "wood");
        object3D[23] = new MuseumObject(objData);

        //Adding ALL of the Museum Objects, including the Museum Room itself
        for(int i = 0; i < 24; i++){
            MuseumTG.addChild(object3D[i].position_Object());
        }


        // Paintings (3 rows of 3)
        for (int i = 0; i < 9; i++) {
            int row = i / 3;
            /**
             * Here we create a 3x3 row of paintings using a little bit of positioning math
             * We also use morphingPaintingData alongside our PaintingObject class to generate these special paintings which can morph
             * Similar to paintingData, morphingPaintingData allows us to input custom picture names when we initialize it
            */
            objData = new morphingPaintingData("Painting", 0.4, new Vector3f((i % 3) * 5 - 35, row * 5, -75), new double[] { 0, -Math.PI / 2, 0 }, "Pic" + i);
            morphingPaintingData pData = (morphingPaintingData) objData;    //Convert it to morphingPaintingData object so we can use it with PaintingObject's morph_shapes method
            MuseumTG.addChild(PaintingObject.morph_Shapes(pData));
        }

        // Strings
        ColorString colorStrings[] = new ColorString[7];    //Array to contain all of the 3D Strings

        //Similar to object creation - initialize the data type, create the object with the data type and add it to MuseumTG
        //Entrance Text
        colorStringData stringData = new colorStringData("Computer Science Museum",1d,new Vector3f(0f,5f,-21.65f),new double[]{0,Math.PI,0},CommonsCode.White);
        colorStrings[0] = new ColorString(stringData);
        //Hall of Fame (paintings) Text
        stringData = new colorStringData("Computer Science Hall of Fame",0.7d,new Vector3f(-11.9f,6f,-30f),new double[]{0,-Math.PI/2,0},CommonsCode.White);
        colorStrings[1] = new ColorString(stringData);
        //Exhibit Text
        stringData = new colorStringData("Evolution of Computers",0.8d,new Vector3f(0f,6f,-21.65f),new double[]{0,0,0},CommonsCode.Blue);
        colorStrings[2] = new ColorString(stringData);
        stringData = new colorStringData("Linux",0.8d,new Vector3f(15.5f,0.65f,-19f),new double[]{0,0,0},CommonsCode.Black);
        colorStrings[3] = new ColorString(stringData);
        stringData = new colorStringData("Storage Devices",0.8d,new Vector3f(-16.5f,6f,-21.65f),new double[]{0,0,0},CommonsCode.White);
        colorStrings[4] = new ColorString(stringData);
        stringData = new colorStringData("Alan Turing",0.8d,new Vector3f(-14.5f,6f,3f),new double[]{0,0,0},CommonsCode.Cyan);
        colorStrings[5] = new ColorString(stringData);
        stringData = new colorStringData("Ada Lovelace",0.8d,new Vector3f(14.5f,6f,3f),new double[]{0,0,0},CommonsCode.Orange);
        colorStrings[6] = new ColorString(stringData);

        //Adding the Strings to our MuseumTG
        for(int i = 0; i < 7; i++){
            MuseumTG.addChild(colorStrings[i].create_Object());
        }

        return MuseumTG;    //Returning the Museum TransformGroup with ALL of the Museum objects in it
    }

    /* A function to create the Scene (content branch) */
    public static BranchGroup create_Scene() {
        BranchGroup sceneBG = new BranchGroup();        //Scene's BranchGroup - We add our finished Museum to this as well as use it for walls and interaction objects
        TransformGroup sceneTG = new TransformGroup();  //Scene's TransformGroup - this will contain the entire Museum and it's contents

        sceneTG.addChild(create_Museum()); //Add everything in the Museum to sceneTG

        sceneBG.addChild(sceneTG);  //Add TransformGroup containing everything to scene's BranchGroup

        sceneBG.addChild(CommonsCode.add_Lights(CommonsCode.White, 1)); //Add light to the scene

        //Adding walls using the addWall method to our scene's BranchGroup - This sets the bounds for our character's movement
        //Walls block us from clipping through objects and the room
        addWall(sceneBG, new Vector3f(0.0f, 2.5f, -21.62f), 60.0f, 9.2f, 0.1f); // Front wall
        addWall(sceneBG, new Vector3f(0.0f, 2.5f, 21.62f), 60.0f, 9.2f, 0.1f); // Back wall
        addWall(sceneBG, new Vector3f(-30.04f, 2.5f, 0.0f), 0.1f, 9.2f, 43.2f); // Left wall
        addWall(sceneBG, new Vector3f(30.04f, 2.5f, 0.0f), 0.1f, 9.2f, 43.2f); // Right wall
        addWall(sceneBG, new Vector3f(14.8f, 2.5f, 0.05f), 13.6f, 9.2f, 4.5f); // Right inner wall
        addWall(sceneBG, new Vector3f(-15f, 2.5f, 0.05f), 13.6f, 9.2f, 4.5f); // Left inner wall

        //In the exhibits section, we also use addInteractiveObject method to add boxes that we can move into and show us a prompt to interact with the object
        // Ada Lovelace
        addWall(sceneBG, new Vector3f(14.5f, 1.0f, 4f), 2.5f, 6f, 2.5f); // Right Painting Interactive object
        addInteractiveObject(sceneBG, new Vector3f(14.5f, 1.0f, 8f), 2.5f, 6f, 10.0f, "Ada Lovelace Exhibit");
        // Alan Turing
        addWall(sceneBG, new Vector3f(-14.5f, 0.8f, 4f), 2.5f, 6f, 2.5f); // Left Painting Interractive object
        addInteractiveObject(sceneBG, new Vector3f(-15f, 0.8f, 8f), 2.5f, 6f, 10.0f, "Alan Turing Exhibit");
        // Evolution of Computers
        addWall(sceneBG, new Vector3f(-0.25f, -0.8f, -20.0f), 8.5f, 6f, 2.5f);
        addInteractiveObject(sceneBG, new Vector3f(-0.25f, -0.8f, -20.0f), 9.0f, 6f, 10.0f,
                "Computers Evolution Exhibit");
        // Storage
        addWall(sceneBG, new Vector3f(-16.5f, -1.5f, -19.0f), 8.5f, 6f, 2.5f);
        addInteractiveObject(sceneBG, new Vector3f(-16.5f, -1.5f, -19.0f), 9.0f, 6f, 10.0f, "Storage Devices Exhibit");
        // Linux
        addWall(sceneBG, new Vector3f(15.5f, -0.8f, -20.0f), 2.5f, 6f, 2.5f);
        addInteractiveObject(sceneBG, new Vector3f(15.5f, -0.8f, -20.0f), 2.5f, 6f, 10.0f, "Linux Exhibit");

        addWall(sceneBG, new Vector3f(-27f, 0.8f, 19f), 5.5f, 6f, 5.5f); // plant 1
        addWall(sceneBG, new Vector3f(27f, 0.8f, 19f), 5.5f, 6f, 5.5f); // plant 2
        addWall(sceneBG, new Vector3f(27f, 0.8f, -19f), 5.5f, 6f, 5.5f); // plant 3
        addWall(sceneBG, new Vector3f(-27f, 0.8f, -19f), 5.5f, 6f, 5.5f); // plant 4

        return sceneBG;
    }

    /**
     * Constructor which takes our created scene/content branch and initializes the rest of the 
     * key features. This is last step (before running main()) to generating the Museum Game.
     */
    public ProjectCode(BranchGroup sceneBG) {
        //
        GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
        canvas3D = new Canvas3D(config);

        // Enable key events and mouse motion events
        canvas3D.addKeyListener(this);
        canvas3D.addMouseMotionListener(this);

        // Specific uses for MouseListener
        canvas3D.addMouseListener(new MouseAdapter() {      //Using anonymous subclassing for conciseness and since we only use these methods once
            //We use mousePressed and mouseReleased to know when we are dragging the mouse to move the camera
            public void mousePressed(MouseEvent e) {    
                //Specifically we use isDragging to toggle between dragging and non-dragging, while also updating our mouse position varaibles
                isDragging = true;
                prevMouseX = e.getX();
                prevMouseY = e.getY();
            }

            public void mouseReleased(MouseEvent e) {
                //End dragging once we stop pressing our mouse button
                isDragging = false;
            }

            public void mouseClicked(MouseEvent e) {
                //Specifically when clicking, we call interactObjects to interact with the selected objects (This uses picking)
                interactObjects(e);
            }
        });


        SimpleUniverse su = new SimpleUniverse(canvas3D); // create a SimpleUniverse

        viewTransformGroup = su.getViewingPlatform().getViewPlatformTransform();    //viewTransformGroup is the simple universe's viewing platform transformGroup
        //Get the simple universes view, so we can set our clip distances
        View view = su.getViewer().getView();
        view.setBackClipDistance(1000.0);   //set it far enough so everything is loaded
        view.setFrontClipDistance(0.1);     //set it short enough 
        updateCameraPosition();             //Update camera position so the starting frame of our camera is proper (without this the camera starts inside of an object)

        sceneBG.compile(); // optimize the BranchGroup
        su.addBranchGraph(sceneBG); // attach the scene to SimpleUniverse

        //InteractionLabel for interactive objects, which we initialized in create_Scene
        interactionLabel = new JLabel("");  //Text will change when we get close enough to an interaction point
        interactionLabel.setFont(new Font("Arial", Font.BOLD, 16)); //Setting up font for label
        interactionLabel.setForeground(Color.red);  //Color of Text
        interactionLabel.setHorizontalAlignment(SwingConstants.CENTER);     //Setting it's screen alignment
        interactionLabel.setBounds(600, 750, 400, 50);     //Creates the box around the text when the interaction text label appears
        interactionLabel.setVisible(false); //Makes the text box invisible until we get close enough to an interaction point

        //Adding our label to the JFrame's layeredPane
        //This means it will appear ABOVE anything else on screen
        JLayeredPane layeredPane = frame.getLayeredPane();
        layeredPane.add(interactionLabel, JLayeredPane.PALETTE_LAYER);

        //Enabling our picking
        pick = new PickCanvas(canvas3D, sceneBG);   // Makes the sceneBG objects pickable
        pick.setMode(PickTool.GEOMETRY);            // Geometric picking (ie. using vectors/geometry to obtain picking results)


        setLayout(new BorderLayout());      //Setting layout of the JFrame
        add("Center", canvas3D);       //Adding canvas3D to JFrame's center (but since its the only thing, it will take up the whole screen)
        frame.setSize(1600, 1600); // set the size of the JFrame
        frame.setVisible(true); 
    }

    //Main method, this initialize the JFrame (alongside everything else through method-calling)
    public static void main(String[] args) {
        frame = new JFrame("COMP 2800 - Team 10 - Museum Explorer");  // Create the JFrame with our desired title
        frame.getContentPane().add(new ProjectCode(create_Scene()));        // Start the program, initializing everything we previously created in ProjectCode/Create_Scene/Create_Museum
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);               // Exit when the window is closed
    }


    //Beginning of method overriding for our mouseListener/keyListener/mouseMotionListener
    @Override
    /**
     * In keyPressed, we use it for movement with WASD (+ space to jump) and for interaction
     */
    public void keyPressed(KeyEvent e) {
        float speed = 0.5f;                 //Speed modifier for movement (applies to all movement)
        Vector3f newPosition = new Vector3f(position);  //newPosition, we update this for WASD movement and jumping

        // Calculate forward/back and right/left vectors based on yaw
        float forwardX = (float) -Math.sin(yaw);
        float forwardZ = (float) -Math.cos(yaw);
        float rightX = (float) Math.cos(yaw);
        float rightZ = (float) -Math.sin(yaw);

        //Switch/case structure for key detection
        switch (e.getKeyCode()) {
            //WASD movement keys
            case KeyEvent.VK_W: // Move forward
                newPosition.x += forwardX * speed;
                newPosition.z += forwardZ * speed;
                break;
            case KeyEvent.VK_S: // Move backward
                newPosition.x -= forwardX * speed;
                newPosition.z -= forwardZ * speed;
                break;
            case KeyEvent.VK_A: // Move left
                newPosition.x -= rightX * speed;
                newPosition.z -= rightZ * speed;
                break;
            case KeyEvent.VK_D: // Move right
                newPosition.x += rightX * speed;
                newPosition.z += rightZ * speed;
                break;
            case KeyEvent.VK_SPACE: // Jump
                if (position.y <= 2.0f) { // Prevent multiple jumps
                    new Thread(() -> {
                        try {
                            float jumpHeight = 0.5f; // How high the player jumps
                            float jumpSpeed = 0.06f; // Controls how smooth the jump is

                            // Ascend (Jump Up)
                            for (float i = 0; i <= jumpHeight; i += jumpSpeed) {    //jump up at jumpSpeed until reaching jumpHeight
                                position.y = 1.6f + i;  //position increases
                                updateCameraPosition(); //update the Camera position
                                Thread.sleep(30); // Delay to control smoothness
                            }

                            // Descend (Fall Down)
                            for (float i = jumpHeight; i >= 0; i -= jumpSpeed) {
                                position.y = 1.6f + i;  //position decreases since i will be reduce over time
                                updateCameraPosition(); //update the Camera position
                                Thread.sleep(30);
                            }

                            position.y = 1.6f; // Ensure player lands correctly
                            updateCameraPosition();

                        } catch (InterruptedException ignored) {
                        }
                    }).start();
                }
                break;
            case KeyEvent.VK_Q: //Q key is the interaction key - when the player is close enough to an object, we can interact with the exhibit
                if (currentObject != null) {
                    //currentObject will be a String corresponding to an exhibit, and exhibit logic will take that string and perform the exhibits function 
                    exhibitLogic(currentObject);    
                }
                break;
        }   //End of key detection

        if (!checkCollision(newPosition)) { //If the player has moved then this will be true 
            //We update the player's position and camera
            position.set(newPosition);  //Update player position
            updateCameraPosition();     //Update Camera Position
        }

        //If we're close enough to an object this will become a usable string, otherwise it's null
        String objectNearby = checkProximity(newPosition);
        if (objectNearby != null) { //If we're close enough, use our interactionLabel to show that the object is interactive
            interactionLabel.setText("Press Q to interact with " + objectNearby);   //Show interaction prompt
            interactionLabel.setVisible(true);  //Make the prompt visible
            currentObject = objectNearby;   //update currentObject (for use in exhibitLogic)
        } else {    //if there is no nearby interactable object
            interactionLabel.setVisible(false); //we make the label disappear
            currentObject = null;   //set currentObject to nothing
        }

    }
    // Unused methods that need to be implemented due to interfaces
    public void keyReleased(KeyEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void keyTyped(KeyEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseMoved(MouseEvent e) {}

    //For mouseDragged, we use this method to move the camera according to how much it is dragged
    public void mouseDragged(MouseEvent e) {
        if (isDragging) {   //If the player is dragging the mouse 
            // Calculate the change in mouse position
            int deltaX = e.getX() - prevMouseX; 
            int deltaY = e.getY() - prevMouseY;
             // Adjust yaw (horizontal rotation) based on mouse movement
            yaw -= deltaX * 0.005f;
            // Adjust pitch (vertical rotation) and constrain it to avoid flipping
            pitch -= deltaY * 0.005f;
            pitch = Math.max(-1.5f, Math.min(1.5f, pitch)); //constrin pitch so we can't flip the camera
            // Update previous mouse coordinates
            prevMouseX = e.getX();
            prevMouseY = e.getY();
            updateCameraPosition(); // Update previous mouse coordinates
        }
    }

    //utility variables that are used to control which sounds we are and aren't playing (both start out of bounds)
    private static int currentPlaying = 9;      //currently playing sound 
    private static int previousPlaying = 10;    //previously playing sound

    /**
     * exhibitLogic takes in a string that will correspond with an exhibit,
     * when it does, it will make the corresponding exhibit interact accordingly
     * all of the exhibits can play sound and some will rotate/stop rotating
     */
    private void exhibitLogic(String currentExhibit) {
        //Each exhibit changes currentPlaying to their respective sound
        //Alan Turing Exhibit
        if (currentExhibit.equals("Alan Turing Exhibit")) {
            currentPlaying = 1; //Changes the currently played track
            object3D[3].get_Rotate().switchAlpha(); // Stops/Resumes Turing Machine Alpha
        } 
        //Ada Lovelace Exhibit
        else if (currentExhibit.equals("Ada Lovelace Exhibit")) {
            currentPlaying = 0;
        } 
        //Linux Exhibit
        else if (currentExhibit.equals("Linux Exhibit")) {
            currentPlaying = 2;
            object3D[17].get_Rotate().switchAlpha(); // Stops/Resumes Penguin/Linux Tux Alpha
        } 
        //Storage Devices Exhibit
        else if (currentExhibit.equals("Storage Devices Exhibit")) {
            currentPlaying = 3;
            object3D[19].get_Rotate().switchAlpha(); // Stops/Resumes Storage Device Alpha
        } 
        //Computer Evolution Exhibit
        else if (currentExhibit.equals("Computers Evolution Exhibit")) {
            currentPlaying = 4;
        }
        //After each of the exhibits has been checked, we check if the track has changed
        if (currentPlaying != previousPlaying) {
            //If it has, it stop all of the other tracks and starts playing the newly selected track
            for (int i = 0; i < 5; i++) {
                soundPlayer.stop(soundNames[i]);
            }
            soundPlayer.play(soundNames[currentPlaying]);
        }
        previousPlaying = currentPlaying;   //Update the previously playing track to the currently playing track
    }

    //checkProximity returns a String, and checks the player's position to see if they're in an interactive object's proximity
    private String checkProximity(Vector3f newPosition) {
        //Create a player bounding box using their position
        BoundingBox playerBox = new BoundingBox(
                new Point3d(newPosition.x - 0.5, newPosition.y - 1.6, newPosition.z - 0.5),
                new Point3d(newPosition.x + 0.5, newPosition.y + 1.6, newPosition.z + 0.5));

        //Check the interactive objects ArrayList
        for (BoundingBox box : interactiveObjects.keySet()) {
            //if the player is in the interactive boxes proximity, return a valid String with the box's name (usable in logic later)
            if (playerBox.intersect(box)) {
                return interactiveObjects.get(box); // return object name
            }
        }
        return null;    //Otherwise return null to show the player isn't interacting with anything
    }

    //checkCollision is similar to checkProximity but for walls instead of interactive objects
    //returns a boolean if the player is colliding with a wall
    private boolean checkCollision(Vector3f newPosition) {
        //Create a player bounding box using their position
        BoundingBox playerBox = new BoundingBox(
                new Point3d(newPosition.x - 0.2, newPosition.y - 1.6, newPosition.z - 0.2),
                new Point3d(newPosition.x + 0.2, newPosition.y + 1.6, newPosition.z + 0.2));

        //Check the wall ArrayList
        for (BoundingBox box : collisionObjects) {
            //if the player is colliding with a wall, return true (which will normally stop player movement in a direction)
            if (playerBox.intersect(box)) {
                return true;  
            }
        }
        return false;   //Otherwise return false to show the player isn't against a wall
    }

    // updateCameraPosition will update the camera position and orientation
    private void updateCameraPosition() {
        //2 Transform3Ds for rotation arithmetic
        Transform3D rotationX = new Transform3D();  //Horizontal Camera Movement
        Transform3D rotationY = new Transform3D();  //Vertical Camera Movement
        rotationX.rotX(pitch);  //Apply pitch rotation
        rotationY.rotY(yaw);    //Apply yaw rotation
        rotationY.mul(rotationX); // Combine yaw and pitch
        rotationY.setTranslation(position); //Apply rotation to our position
        viewTransformGroup.setTransform(rotationY); //also apply rotation to our view, updating our camera
    }

    /**
     * addWall takes in the scene's BranchGroup and the position, width, height, and depth of a BoundingBox that we'll use for our walls
     */
    private static void addWall(BranchGroup sceneBG, Vector3f position, float width, float height, float depth) {
        //Create the bounding box with the given parameters in the given position
        BoundingBox wallBounds = new BoundingBox(
                new Point3d(position.x - width / 2, position.y - height / 2, position.z - depth / 2),
                new Point3d(position.x + width / 2, position.y + height / 2, position.z + depth / 2));
        //Add the bounding box to our BoundingBox ArrayList (which is used to check collision later)
        collisionObjects.add(wallBounds);
    }

    /**
     *  addInteractiveObject takes in the scene's BranchGroup and the position, width, height, and depth of a BoundingBox
     *  in order to generate a box for an interactive object. It also takes in a name for the box, which let's us identify
     *  the specific box when performing logic with it.
     */
    private static void addInteractiveObject(BranchGroup root, Vector3f position, float width, float height, float depth, String name) {
        //Create the bounding box with the given parameters in the given position
        BoundingBox objectBounds = new BoundingBox(
                new Point3d(position.x - width / 2, position.y - height / 2, position.z - depth / 2),
                new Point3d(position.x + width / 2, position.y + height / 2, position.z + depth / 2));
        //Add the bounding box to our BoundingBox Map which allows us to also add it's name and identify it in the Map with it's name
        interactiveObjects.put(objectBounds, name);
    }

    /**
     * interactObjects takes in a MouseEvent (from MouseClicked) and uses it to interact with a clicked exhibit.
     */
    private void interactObjects(MouseEvent e) {
        // Obtaining click location with geometry
        int x = e.getX();
        int y = e.getY(); // mouse coordinates
        Point3d point3d = new Point3d(), center = new Point3d();    //3D points for click location and for the viewer's eye centre
        canvas3D.getPixelLocationInImagePlate(x, y, point3d);   //Getting the click location
        canvas3D.getCenterEyeInImagePlate(center);              //Getting the viewer's eye centre

        Transform3D transform3D = new Transform3D();    // matrix to relate ImagePlate coordinates~
        canvas3D.getImagePlateToVworld(transform3D);    // to Virtual World coordinates
        transform3D.transform(point3d);                 // transform 'point3d' with 'transform3D'
        transform3D.transform(center);                  // transform 'center' with 'transform3D'

        //Calculating the vector from the viewer's eye centre to the click location
        Vector3d mouseVec = new Vector3d(); 
        mouseVec.sub(point3d, center);  // obtaining vector
        mouseVec.normalize();           // normalize the vector

        pick.setShapeRay(point3d, mouseVec); // Using this point and vector as a picking ray for geometric intersection

        //Obtain a result from the geometric clicking (specifically the first/closest result that is obtained)
        PickResult result = pick.pickClosest();
        //If the result is valid, we create Node object that we can match to one of our objects
        if (result != null) {
            Node pickNode = null;
            //Identify the Node as a Shape3D
            pickNode = result.getNode(PickResult.SHAPE3D);
            //If the result is valid, we can obtain the Node's name and compare it with one of our possible exhibit object names
            if (pickNode != null) {
                String name = pickNode.getName();   //Get the Node's name
                System.out.println("Picked Shape3d: " + pickNode.getName());
                //Check it with each of the possible exhibit object names and activate that exhibit if it matches
                //Ada Lovelace
                if (name.equals("AdaLovelace") || name.equals("Poster1") || name.equals("Ada LovelaceString")) {
                    exhibitLogic("Ada Lovelace Exhibit");   //Activates the exhibit if the clicked object matches
                }   
                //Alan Turing
                if (name.equals("AlanTuring") || name.equals("TuringMachine") || name.equals("Alan TuringString")) {
                    exhibitLogic("Alan Turing Exhibit");
                }
                //Linux
                if (name.equals("Tux") || name.equals("Tuxfinal") || name.equals("LinuxString")) {
                    exhibitLogic("Linux Exhibit");
                }
                //Storage Devices
                if (name.equals("USB") || name.equals("floppydisk1") || name.equals("CD") || name.equals("rtable")
                        || name.equals("StorageDevice") || name.equals("Storage DevicesString")) {
                    exhibitLogic("Storage Devices Exhibit");
                }
                //Evolution of Computers
                if (name.equals("EvlofComp3") || name.equals("EvolutionOfComputers") || name.equals("Evolution of ComputersString")) {
                    exhibitLogic("Computers Evolution Exhibit");
                }
            }
        }
    }

}
