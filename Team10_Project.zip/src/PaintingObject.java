/**
 * PaintingObject.java
 * Allows creation of special morphing painting objects that can be placed in the Museum
 */

import java.util.ArrayList;

import org.jogamp.java3d.Alpha;
import org.jogamp.java3d.Transform3D;
import org.jogamp.java3d.TransformGroup;
import org.jogamp.vecmath.Vector3f;

import org.jdesktop.j3d.examples.morphing.MorphingBehavior;
import org.jogamp.java3d.Appearance;
import org.jogamp.java3d.ImageComponent2D;
import org.jogamp.java3d.Morph;
import org.jogamp.java3d.PolygonAttributes;
import org.jogamp.java3d.TexCoordGeneration;
import org.jogamp.java3d.Texture2D;
import org.jogamp.java3d.TextureAttributes;
import org.jogamp.java3d.TriangleStripArray;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.Point3f;
import org.jogamp.vecmath.Vector3d;

public class PaintingObject {

	//morph_Shapes designates each part of the morping painting were generating
	//Uses special morphingPaintingData data type which contains all of the needed data to generate these paintings
	public static TransformGroup morph_Shapes(morphingPaintingData data) {
		String[] side_name = { "Top", data.getContent(), "Side", "Outer", "Frame1", "Frame2" };
		ArrayList<Transform3D> tf = new ArrayList<Transform3D>();			//Transform3D ArrayList for each part of the painting
		ArrayList<TransformGroup> tg = new ArrayList<TransformGroup>();		//TransformGroup ArrayList for each part of the painting
		//Translations for each part of the painting
		Vector3f[] translations = {
				new Vector3f(0.0f, 0, -0.1f), // Top
				new Vector3f(0.0f, 0, 0.1f), // Pic1
				new Vector3f(0f, 0f, 0f), // Side
				new Vector3f(0f, 0f, 0f), // Outer
				new Vector3f(0f, 0f, 0f), // Frame1
				new Vector3f(0f, 0f, 0f) // Frame2
		};
		// Scales the entire object
		Transform3D scaleTF = new Transform3D();
		scaleTF.setScale(data.getScale());
		TransformGroup scaleTG = new TransformGroup(scaleTF);

		// Translates the entire object
		Transform3D transTF = new Transform3D();
		transTF.setTranslation(data.getTranslation());
		TransformGroup transTG = new TransformGroup(transTF);

		// Rotates the entire object
		TransformGroup rotTG = rotation(data.getRotations());

		int totalObj = 6;	//total objects count, each is a different part of the painting
		// Create Objects add them to the final TransformGroups with their morphing behaviour
		for (int i = 0; i < totalObj; i++) {
			tf.add(new Transform3D());		//Create new Transform3D
			tf.get(i).setTranslation(translations[i]);	//Apply individual translation to Transform3D
			//Add a new TransformGroup to the ArrayList that uses the previous Transform3D
			tg.add(new TransformGroup(tf.get(i)));		
			//Add the morphing behaviour as a child to the current TransformGroup (part of the painting)
			tg.get(i).addChild(set_Morph(tg.get(i), side_name[i], 4, 8, 16, 32, 64));	//set_Morph creates the morphing behaviour
			transTG.addChild(tg.get(i));	//Add every finished TransformGroup to the translation TransformGroup
		}

		scaleTG.addChild(transTG);	//add the translation TG to the scale TG
		rotTG.addChild(scaleTG);	//add the scale TG the rotation TG
		return rotTG;	//return the rotation TG with the finished morphing painting
	}

	//rotation sets up a singular rotation for neatly placing the paintings
	public static TransformGroup rotation(double rotations[]) {	//rotations is obtained earlier from our custom data type
		// Perform rotations with Transform3D's
		Transform3D x_axis = new Transform3D();		//x-axis rotations
		Transform3D y_axis = new Transform3D();		//y-axis rotations
		Transform3D z_axis = new Transform3D();		//z-axis rotations
		x_axis.rotX(rotations[0]);		//Apply x-axis rotations
		y_axis.rotY(rotations[1]);		//Apply y-axis rotations
		z_axis.rotZ(rotations[2]);		//Apply z-axis rotations

		// Combine rotations
		x_axis.mul(y_axis);		// combine x and y
		x_axis.mul(z_axis);		// combine x and y and z

		return new TransformGroup(x_axis);	//set our object's rotation TransformGroup to a new TG defined by the rotations
	}

	private final static int M_PTS = 64; // define maximum number of circle points

	//Remove deprecation warnings for morph
	@SuppressWarnings("deprecation")
	//set_Morph will create the morphs for the given sides
	//Takes in a TG (part of the painting), String for the part name, and range of numbers for the different amount vertices for each morph
	public static Morph set_Morph(TransformGroup parentTG, String s, int n0, int n1, int n2, int n3, int n4) {
		int[] num = { n0, n1, n2, n3, n4 };	//Array of the vertex range
		TriangleStripArray[] geoArray = get_Objects(s, num);	//create a Triange Strip Array with vertex range and part name, using get_Objects
		Morph morph;	//Initialize the morph
		if (s == "Side" || s == "Outer" || s == "Frame1" || s == "Frame2") {	//The outer parts (frame) of the painting are textured with the frame image
			morph = new Morph(geoArray, set_Appearance("Frame"));		//initalize the morph with the geometry and frame appearance
		} else {	//Any other part is textured with the given part name
			morph = new Morph(geoArray, set_Appearance(s));		//initalize the morph with the geometry and given appearance
		}
		morph.setCapability(Morph.ALLOW_WEIGHTS_WRITE);	// Allow the morph weights to be changed during runtime
		  // Create a morphAlpha to control morph timing
		Alpha morphAlpha = new Alpha(-1, Alpha.INCREASING_ENABLE | Alpha.DECREASING_ENABLE, 0, 0, 4000, 0000, 1000, 4000, 0000, 1000);
		// Create a MorphingBehavior to animate the Morph node using the Alpha
		MorphingBehavior mBeh = new MorphingBehavior(morphAlpha, morph);
		mBeh.setSchedulingBounds(CommonsCode.twentyBS); // enable morphing behavior with a scheduling bound
		parentTG.addChild(mBeh); // attach morphing behavior to 'parentTG'
		return morph;	//return the part with the morphing behavior
	}

	//Returns an array of TriangleStripArray objects, each representing a different shape
	//But with the same number of vertices, for morphing
	public static TriangleStripArray[] get_Objects(String s, int[] n) {
		int num = 3; // number of shapes to generate
		TriangleStripArray[] geoArray = new TriangleStripArray[num];
		for (int i = 0; i < num; i++){ 
			// Generate a TriangleStripArray using the shape name and edge count for the entire range of vertices
			geoArray[i] = ring_Side(s, n[i]);	//uses ring_Side to generate the TriangleStripArrays
		}
		return geoArray; // return the array of geometries
	}


	//Returns a TriangleStripArray geometry based on a shape key and number of edges
	private static TriangleStripArray ring_Side(String shape_key, int num) {
		float r = 2.0f; // place points on a circle with radius 'r'

		if (shape_key == "Outer") {
			r = 2.3f; // Outer ring uses a slightly larger radius
		}


		int v_num = (M_PTS + 1) * 2; // use 'M_PTS+1' points on two circles for the surface
		int vn_count[] = { v_num }; // set point counters for the surface
		Point3f[] v_cdnts = new Point3f[v_num]; // allocate 3D coordinates for all surface points
		Vector3f[] c_nmls = new Vector3f[v_num]; // declare normals for the set of points
		Vector3f nml;	//Normal for the points
		double nt; // declare variables for the calculation of normal
		float x0, y0;	//float variables that will cycle through each point in the circle
		// prepare points on the circle
		Point3f c_pts[] = circle_Points(0, r, M_PTS);	//points on the circle with given radius and points
		Point3f ctr_pt = new Point3f(0f, 0f, 0.1f);		//center point
		Point3f p1, p2;	//point3f from the circle points

		int k;
		double rpt = M_PTS / num; // repeated points (when num is less than max)
		for (int i = 0; i <= M_PTS; i++) {
			k = (i < M_PTS) ? i : 0; // NOTE: set the last two points as the first two points

			if (k != 0 && M_PTS != num) { // place multiple points at the same location if 'num'<M_PTS
				k = (int) (k / rpt);
				k = k * (int) rpt;
			}

			if (shape_key == "Side") {	//Side points
				//Get points from circle
				p1 = new Point3f(c_pts[k].x, c_pts[k].y, -0.15f);
				p2 = new Point3f(c_pts[k].x, c_pts[k].y, 0.15f);
				//Get normals
				x0 = c_pts[k].x;
				y0 = c_pts[k].y;
				//distance = sqrt(x^2 + y^2)
				nt = Math.sqrt(x0 * x0 + y0 * y0); // normalize the normals of side (vertical) surface points
				nml = new Vector3f((float) (x0 / nt), (float) (y0 / nt), 0f);
			} else if (shape_key == "Outer") {	//Outer edge points
				p1 = new Point3f(c_pts[k].x, c_pts[k].y, -0.15f);
				p2 = new Point3f(c_pts[k].x, c_pts[k].y, 0.15f);
				x0 = c_pts[k].x;
				y0 = c_pts[k].y;
				nt = Math.sqrt(x0 * x0 + y0 * y0); // normalize the normals of side (vertical) surface points
				nml = new Vector3f((float) (x0 / nt), (float) (y0 / nt), 0f);
			} else if (shape_key == "Frame1") {
				// For the inner frame edge (connecting inner part)
				float innerRadius = 2.0f; // Same as the default radius
				float outerRadius = 2.3f; // Same as the Outer radius

				// Create points that connect inner and outer circles at the front face
				p1 = new Point3f(c_pts[k].x * (innerRadius / r), c_pts[k].y * (innerRadius / r), 0.15f);
				p2 = new Point3f(c_pts[k].x * (outerRadius / r), c_pts[k].y * (outerRadius / r), 0.15f);

				// Calculate normal (pointing outward from the center)
				x0 = c_pts[k].x;
				y0 = c_pts[k].y;
				nt = Math.sqrt(x0 * x0 + y0 * y0);
				nml = new Vector3f(0f, 0f, 1f); // Normal pointing in Z direction for flat surface
			} else if (shape_key == "Frame2") {
				// For the inner frame edge (connecting inner part on the other side of the frame)
				float innerRadius = 2.0f; // Same as the default radius
				float outerRadius = 2.3f; // Same as the "Outer" radius

				// Create points that connect inner and outer circles at the back face
				p1 = new Point3f(c_pts[k].x * (innerRadius / r), c_pts[k].y * (innerRadius / r), -0.15f);
				p2 = new Point3f(c_pts[k].x * (outerRadius / r), c_pts[k].y * (outerRadius / r), -0.15f);

				// Normal facing backward
				x0 = c_pts[k].x;
				y0 = c_pts[k].y;
				nt = Math.sqrt(x0 * x0 + y0 * y0);
				nml = new Vector3f(0f, 0f, -1f); // Normal pointing in negative Z direction
			} else {
				//Generating the painting (part with the image on it)
				p1 = new Point3f(c_pts[k].x, c_pts[k].y, 0f);
				p2 = ctr_pt;
				nml = new Vector3f(0f, 0f, 1f);
			}
			v_cdnts[i * 2 + 1] = p1; // set the coordinate for the point on a surface
			v_cdnts[i * 2] = p2;	
			c_nmls[i * 2] = c_nmls[i * 2 + 1] = nml; // normalize
		}

		//Create the TriangleStripArray with our obtained points/variables
		TriangleStripArray object_geometry = new TriangleStripArray(v_num,TriangleStripArray.COORDINATES | TriangleStripArray.NORMALS, vn_count);
		object_geometry.setStripVertexCounts(vn_count); // create the object as a TriangleStripArray
		object_geometry.setCoordinates(0, v_cdnts, 0, v_num); //Set the geometry's coordinates
		object_geometry.setNormals(0, c_nmls, 0, v_num); // set the geometry's normals

		return object_geometry;	//Return the TraingleStripArray
	}

	//set_Appearance
	public static Appearance set_Appearance(String s) {
		Appearance app = CommonsCode.set_Appearance(CommonsCode.White);	//Create a new appearance with white color as a base
		PolygonAttributes pa = new PolygonAttributes();	//Create polygon attributes
		pa.setCullFace(PolygonAttributes.CULL_NONE); // show both sides
		app.setPolygonAttributes(pa);	//apply polygon attributes (showing both sides) to appearance
	
		// Generate texture coordinates
		TexCoordGeneration tcg = new TexCoordGeneration(TexCoordGeneration.OBJECT_LINEAR,
				TexCoordGeneration.TEXTURE_COORDINATE_2);
		app.setTexCoordGeneration(tcg);		//Set appearance's texture coordinate generation
		app.setTexture(texture_Appearance("Painting" + s));	//Set it's texture to the corresponding file in /images

		TextureAttributes textureAttrib = new TextureAttributes();	// Create new texture attributes	
		textureAttrib.setTextureMode(TextureAttributes.REPLACE);	// Replace object color with texture
		app.setTextureAttributes(textureAttrib);					// Apply Texture Attributes

		float scl = 0.250f; //scaling base value
		Vector3d scale = new Vector3d(scl, scl, scl);	//scaling vector3d made with the scaling base value
		Transform3D transMap = new Transform3D();	//New Transform3D for image scaling
		transMap.setScale(scale);	//Apply scaling to Transform3D
		textureAttrib.setTextureTransform(transMap);	//Apply Texture Transform to texture attributes

		return app;
	}

	//texture_Appearance will take a filename and return that files image as a Texture2D
	private static Texture2D texture_Appearance(String f_name) {
		String file_name = "images/" + f_name + ".jpg"; // indicate the location of the image
		TextureLoader loader = new TextureLoader(file_name, null);	//Create textureLoader with the filename
		ImageComponent2D image = loader.getImage(); // get the image
		if (image == null){	//If loading fails
			System.out.println("Cannot load file: " + file_name);
		}
		//Create the new Texture2D with our image's values
		Texture2D texture = new Texture2D(Texture2D.BASE_LEVEL,Texture2D.RGBA, image.getWidth(), image.getHeight());
		texture.setImage(0, image); // define the texture with the image
		return texture;		//return the finished Texture2D
	}

	//circle_Points returns the points on a circle given a number of points, radius, and z-point
	public static Point3f[] circle_Points(float z, float r, int n) {
		float x, y;		//x and y values for the points
		Point3f c_pts[] = new Point3f[n]; // declare 'n' number of points

		//calculating a the number of given points
		for (int i = 0; i < n; i++) { 
			// calculate x and y
			x = (float) Math.cos(Math.PI / 180 * (360.0 * i / n)) * r;	//both use the radius
			y = (float) Math.sin(Math.PI / 180 * (360.0 * i / n)) * r;
			//The points on the circle are place  at the given z-point
			c_pts[i] = new Point3f(x, y, z); // set points on the circle
		}

		return c_pts; //return the array of circle points
	}

}
