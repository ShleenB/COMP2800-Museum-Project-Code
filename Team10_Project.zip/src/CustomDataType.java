/*
 * CustomDataType.java
 * Sets up a number of CustomDataTypes which are taken by the other classes in this code.
 * This allows for a large amount of modularity and makes it easier to modify classes/methods
 * without having to rewrite large amounts of code.
 */

import org.jogamp.java3d.Alpha;
import org.jogamp.vecmath.Color3f;
import org.jogamp.vecmath.Vector3f;

//Basic, abstract CustomDataType class, superclass to all other custom data types
public abstract class CustomDataType {

    //getAll will simply return an array of all the data type's variables
    abstract Object[] getAll();

    //Empty constructor
    public CustomDataType() {
    }

}

//ObjectData is for building basic 3D objects, primarily those with .obj models
//extends CustomDataType and implements it's abstract classes
class ObjectData extends CustomDataType {
    String objName;     //Object Name
    double scale;       //Object Scale
    Vector3f translate; //Object Translation

    //Empty Constructor
    public ObjectData() {
    }

    //Basic Constructor, takes all required variables
    public ObjectData(String objName, double scale, Vector3f translate) {
        this.objName = objName;
        this.scale = scale;
        this.translate = translate;
    }

    //Getters for all unique variables
    public String getObjectName() {
        return objName;
    }
    public double getScale() {
        return scale;
    }
    public Vector3f getTranslation() {
        return translate;
    }

    //Inherited getAll
    public Object[] getAll() {
        Object[] retArray = { objName, scale, translate };
        return retArray;
    }
}

//positionData is very similar to ObjectData, but adds the singular rotation functionality
class positionData extends ObjectData {
    double rotations[];     //Added double array for rotations

    //Empty Constructor
    public positionData() { 
    }

    //Basic constructor now also includes rotations
    public positionData(String objName, double scale, Vector3f translate, double[] rot) {
        super(objName, scale, translate);   //Use ObjectData's constructor for the old values
        rotations = rot;    //manually set rotation
    }

    //Getter for rotations
    public double[] getRotations() {
        return rotations;
    }

    //getAll includes rotations
    public Object[] getAll() {
        Object[] retArray = { objName, scale, translate, rotations };
        return retArray;
    }
}

//morphingPaintingData is a special-case data type which includes a content String that's used when generating
//the image for the painting.
//extends positionData, so it can be rotated among all of it's other features
class morphingPaintingData extends positionData {
    String content;     //Painting Content String

    //Basic constructor contains content
    public morphingPaintingData(String objName, double scale, Vector3f translate, double[] rot, String content) {
        super(objName, scale, translate, rot);
        this.content = content;
    }

    //Getter for content
    public String getContent() {
        return content;
    }

    //getAll includes painting content
    public Object[] getAll() {
        Object[] retArray = { objName, scale, translate, rotations,content };
        return retArray;
    }
}

//paintingData is another special-case data type which includes a content String and frame String.
//Both are for added customization in the textures used by the painting when it's generated
//extends positionData, so it can be rotated among all of it's other features
class paintingData extends positionData {
    String content;     //The main content of painting's image
    String frame;       //The frame of the painting's image

    //Basic constructor includes content and frame Strings
    public paintingData(String objName, double scale, Vector3f translate, double[] rot, String content, String frame) {
        super(objName, scale, translate, rot);
        this.content = content;
        this.frame = frame;
    }

    //getters for both content and frame
    public String getContent() {
        return content;
    }
    public String getFrame() {
        return frame;
    }

    //getAll includes painting content and frame
    public Object[] getAll() {
        Object[] retArray = { objName, scale, translate, rotations,content,frame };
        return retArray;
    }
}

//colorStringData is the final special-case data type, which includes a Color3f for the font color.
//colorStringData is primarily used for generating 3D colored strings.
//extends position data, so it includes the translation, scaling, rotation values as a result.
class colorStringData extends positionData {
    Color3f color;  //Color3f for coloring the Strings

    //Empty constructor
    public colorStringData() {
    }
    //Basic construcor includes a Color3f value
    public colorStringData(String objName, double scale, Vector3f translate, double[] rot, Color3f c) {
        super(objName, scale, translate, rot);
        color = c;
    }
    //Getter for the color
    public Color3f getColor() {
        return color;
    }

    //getAll includes our new color variable
    public Object[] getAll() {
        Object[] retArray = { objName, scale, translate, rotations, color };
        return retArray;
    }

}

//rotatingPositionData adds the continuous rotation functionality to positionData
//adds an axis character and alpha variable which can be used by RotateObject
class rotatingPositionData extends positionData {
    char axis;      //axis character is used for determining axis of rotation
    Alpha alpha;    //Alpha contains the specifications for how the object rotates

    //Empty Constructor
    public rotatingPositionData() {
    }
    //Basic Constructor includes axis character and alpha
    public rotatingPositionData(String objName, double scale, Vector3f translate, double rot[], char axis,Alpha alpha) {
        super(objName, scale, translate, rot);
        this.axis = axis;
        this.alpha = alpha;
    }

    //Getters for both axis and alpha
    public char getAxis() {
        return axis;
    }
    public Alpha getAlpha() {
        return alpha;
    }

    //getAll includes axis and alpha
    public Object[] getAll() {
        Object[] retArray = { objName,scale,translate,rotations, axis, alpha };
        return retArray;
    }
}