/**
 * ColorString.java
 * Allows us to create 3D text objects using strings.
 * Will specifically generate TransformGroups of the 3D text objects with applied transformations and color
 */

import java.awt.Font;
import org.jogamp.java3d.*;
import org.jogamp.vecmath.*;

class ColorString {
	private colorStringData data;	//Data type for colorStrings, includes a Color3F so we can designate color

	public ColorString(colorStringData data) {	//Takes in custom data type for colorStrings
		this.data = data;	//Initialize our data
	}

	//create_Object will generate our string as a 3D object and return it as a TransformGroup
	//It will also apply transformations to it
	protected Node create_Object() {
		// Create a Text3D object using the content from data
		Font3D font3D = new Font3D(new Font("SansSerif", Font.PLAIN, 1), new FontExtrusion());	//new font3D with basic FontExtrusion
		Text3D text3D = new Text3D(font3D, data.getObjectName());	//Use the objectName from our custom data type for the string
		Appearance app; 		//Appearance for the string

		// Center-Align the generated text
		text3D.setAlignment(Text3D.ALIGN_CENTER);

		Shape3D textShape = new Shape3D(text3D);	//Create a Shape3D with the text
		textShape.setName(data.getObjectName() + "String");		//Name the object so it can be identified during picking

		// Create and set the appearance for the text
		app = new Appearance();
		// Creating a material for the appearance
		Color3f color = data.getColor();
		Material material = new Material();
		material.setDiffuseColor(color);
		material.setAmbientColor(color);
		material.setSpecularColor(new Color3f(1.0f, 1.0f, 1.0f));
		material.setShininess(60.0f);
		material.setLightingEnable(true);
		//Apply material to appearance
		app.setMaterial(material);

		// Apply the appearance to the shape
		textShape.setAppearance(app);

		// Translating
		Vector3f translation = data.getTranslation();	//Get translation from data type
		Transform3D transTF = new Transform3D();	//New Transform3D for transformation
		transTF.setTranslation(translation);		//Apply transformation to Transform3D
		TransformGroup transTG = new TransformGroup(transTF);	//Create new TG with our Transform3D

		// Scaling
		Transform3D scaleTF = new Transform3D();	//New Transform3D
		scaleTF.setScale(data.getScale());		//Apply scale to Transform3D
		TransformGroup scaleTG = new TransformGroup(scaleTF);	//Create new TG with our Transform3D

		// Rotation
		TransformGroup rotTG = PaintingObject.rotation(data.getRotations());	//Using rotation method to streamline

		
		scaleTG.addChild(textShape);	// Add the text shape to the scale group
		transTG.addChild(scaleTG);		// Add the scale group to translation group
		rotTG.addChild(transTG);		// Add the translation group to rotation group

		// Return the positioned text
		return rotTG;
	}

}