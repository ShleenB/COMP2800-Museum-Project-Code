/*
 * BuildObjects.java
 * Used to build/import 3D .obj objects in the 3D environment
 * Imports, Colours, and Translates 3D .obj objects
 * 
 * Has MuseumObject class which contains all of the necessary
 * methods and data to fully create the object in the Museum
 */

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.jogamp.java3d.*;
import org.jogamp.java3d.loaders.*;
import org.jogamp.java3d.loaders.objectfile.ObjectFile;
import org.jogamp.java3d.utils.image.TextureLoader;
import org.jogamp.vecmath.*;

//BuildObjects is the base, abstract class
public abstract class BuildObjects {
	//Variable declaration (contains all of the necessary variables for things like translation, rotation, scaling, coloring, and more)
	protected ObjectData data;		//ObjectData variable will contain most of the info we need to make the object
	protected Alpha rotationAlpha;	//rotationAlpha for if the object has continuous rotation
	protected BranchGroup objBG; 	// load external object to 'objBG'
	protected TransformGroup objTG; // use 'objTG' to position an object
	protected TransformGroup objRG; // use 'objRG' to rotate an object
	protected double scale; 	// use 'scale' to define scaling
	protected Vector3f post; 	// use 'post' to specify location
	protected Shape3D obj_shape_array[];	//This array will hold all of the object's parts which allows us to seperately colour the parts
	protected String obj_name; // obj_name is used to identify the object, in cases like picking
	protected RotateObject rotateObject;	//rotateObject allows us to finely control the objects rotation
	protected Boolean isRotating;			//isRotating is set to true if the object has continuous rotation
	protected Boolean isPainting = false;	//isPainting is set to true if the object is a painting, this changes how we texture it
	protected String paintingContent, paintingFrame;	//paintingContent/Frame are strings which contain the names of the painting textures for the frame and content
	protected static Vector3d imageVec;		//imageVec changes how the textures are displayed, this is updated depending on what texture we're using

	//ArrayLists for Material and Appearances, we use these to hold our custom colours/appearances
	protected static ArrayList<Material> materials = new ArrayList<>();
	protected static ArrayList<Appearance> appearances = new ArrayList<>();

	public abstract TransformGroup position_Object(); 		//abstract position_Object method where we set the object positioning
	public abstract void add_Child(TransformGroup nextTG);	//abstract add_Child allows us to add children to our transformGroup

	public Alpha get_Alpha() {return rotationAlpha;};		//get_Alpha lets us get the Alpha of our object
	public RotateObject get_Rotate() {return rotateObject;}	//get_Rotate lets us get the rotateObject of our object, which we can manipulate


	//loadShape let's us load object files (.obj) with the given filename
	private Scene loadShape(String obj_name) {
		//Creating a new objectFile
		ObjectFile f = new ObjectFile(ObjectFile.RESIZE, (float) (60 * Math.PI / 180.0));
		Scene s = null;
		try { // Attempt to load the object (which should be in the objects folder)
			s = f.load("objects/" + obj_name + ".obj");
		} 
		//Otherwise catch the exception, print it, and exit
		catch (FileNotFoundException e) {
			System.err.println(e);
			System.exit(1);
		} 
		catch (ParsingErrorException e) {
			System.err.println(e);
			System.exit(1);
		} 
		catch (IncorrectFormatException e) {
			System.err.println(e);
			System.exit(1);
		}
		return s; // If successful, return the object as a scene
	}

	/*
	 * transform_Object will scale and translate the object, while also
	 * loading it using loadShape, and obtaining it's parts to place them in
	 * obj_shape_array.
	 */
	protected void transform_Object(String obj_name) {
		//Scaling and Translating
		Transform3D scaler = new Transform3D();
		scaler.setScale(scale); 						// set scale for the 4x4 matrix
		scaler.setTranslation(post); 					// set translations for the 4x4 matrix
		objTG = new TransformGroup(scaler);			 	// set the translation BG with the 4x4 matrix
		objBG = loadShape(obj_name).getSceneGroup(); 	// load external object to 'objBG'

		// Obtaining all parts of the object
		List<Shape3D> shapeList = new ArrayList<>();	//We'll add all of the valid (Shape3D) parts to this List
		int numParts = objBG.numChildren();		//Amount of children
		for (int i = 0; i < numParts; i++) {
			Node child = objBG.getChild(i);		//Iterate through each child and check if they're Shape3Ds
			if (child instanceof Shape3D) {
				Shape3D shapeChild = (Shape3D) child;	//If the part is a Shape3D, then it's usable
				shapeChild.setName(obj_name); // Use name to identify the object and it's parts
				if (isPainting) {
					shapeChild.setName(paintingContent);	//Alternate naming for paintings
				}
				shapeList.add(shapeChild);	//Add the Shape3D parts/children to our list
			}
		}
		obj_shape_array = shapeList.toArray(new Shape3D[0]);	//get all of the parts into our obj_shape_array for manipulation in appearance selection
	}

	//create_Materials initializes the materials and appearances ArrayLists, this method is called before anything else in create_Museum
	protected static void create_Materials() {
		//Create the numerous materials we'll use and add them to the material ArrayList
		materials.add(new Material(new Color3f(0.7f, 0.7f, 0.7f), new Color3f(0.4f, 0.4f, 0.2f),new Color3f(0.2f, 0.2f, 0.2f), new Color3f(0.0f, 0.0f, 0.0f), 0)); // 0 - Green
		materials.add(new Material(new Color3f(0.5f, 0.1f, 0.1f), new Color3f(0.8f, 0.2f, 0.2f),new Color3f(1.0f, 0.3f, 0.3f), new Color3f(0.0f, 0.0f, 0.0f), 20.0f)); // 1
		materials.add(new Material(new Color3f(0.2f, 0.2f, 0.2f), new Color3f(0.3f, 0.3f, 0.3f),new Color3f(0.4f, 0.4f, 0.4f), new Color3f(0.0f, 0.0f, 0.0f), 30.0f)); // 2 - Dark Grey
		materials.add(new Material(new Color3f(0.1f, 0.1f, 0.1f), new Color3f(0.2f, 0.2f, 0.2f),new Color3f(0.3f, 0.3f, 0.3f), new Color3f(0.0f, 0.0f, 0.0f), 30.0f)); // 3
		materials.add(new Material(new Color3f(0.05f, 0.05f, 0.05f), new Color3f(0.1f, 0.1f, 0.1f),new Color3f(0.2f, 0.2f, 0.2f), new Color3f(0.0f, 0.0f, 0.0f), 10.0f)); // 4 - Very Dark Grey
		materials.add(new Material(new Color3f(0.0f, 0.0f, 0.0f), new Color3f(0.0f, 0.0f, 0.0f),new Color3f(0.1f, 0.1f, 0.1f), new Color3f(0.2f, 0.2f, 0.2f), 100.0f)); // 5 - black
		materials.add(new Material(new Color3f(0.8f, 0.8f, 0.8f), new Color3f(1.0f, 1.0f, 1.0f),new Color3f(0.9f, 0.9f, 1.0f), new Color3f(1.0f, 1.0f, 1.0f), 128.0f)); // 6
		materials.add(new Material(new Color3f(1.0f, 1.0f, 1.0f), new Color3f(1.0f, 1.0f, 1.0f),new Color3f(1.0f, 1.0f, 1.0f), new Color3f(1.0f, 1.0f, 1.0f), 60.0f)); // 7 - White
		materials.add(new Material(new Color3f(1.0f, 0.5f, 0.0f), new Color3f(1.0f, 0.5f, 0.0f),new Color3f(1.0f, 0.5f, 0.0f), new Color3f(1.0f, 0.5f, 0.0f), 60.0f)); // 8 - Orange
		materials.add(new Material(new Color3f(0.545f, 0.271f, 0.075f),new Color3f(0.0f, 0.0f, 0.0f),new Color3f(0.545f, 0.271f, 0.075f), new Color3f(1.0f, 1.0f, 1.0f), 64.0f)); // 9 - Tree Brown
		materials.add(new Material(new Color3f(0.0f, 0.2f, 0.0f),new Color3f(0.0f, 0.0f, 0.0f),new Color3f(0.0f, 0.8f, 0.2f),new Color3f(0.9f, 0.9f, 0.6f), 32.0f)); // 10 - Leaf Green

		//Get the total of the materials
		int totalMtl = materials.size();
		for (int i = 0; i < totalMtl; i++) {
			// add a new appearance to the appearance arrayList and set that new appearance's material to one of our defined materials
			appearances.add(new Appearance());
			appearances.get(i).setMaterial(materials.get(i));
		}
	}

	/*
	 * obj_Appearance contains the number of different customized appearances for our objects
	 * we identify the object by it's name, and then apply either an image texture (set_Appearance) or
	 * a Java3D material/appearance (setAppearance) to each of it's parts which we access through 
	 * obj_shape_array.
	 * We also change imageVec depending on how large/small we want the image texture to be.
	 */
	protected void obj_Appearance() {
		if (obj_name.equals("MuseumRoom")) {	//For the Museum Room
			imageVec = new Vector3d(10.0, 10.0, 10.0);	//Modify imageVec so the image textures are the proper size (important for repeating textures)
			//Use set_Appearance to apply the image texture to the given object/object part
			set_Appearance("celing", obj_shape_array[0], true); // Cieling
			set_Appearance("good", obj_shape_array[8], true); // Floor

			// 1-3 & 9 (Outer Walls)
			imageVec = new Vector3d(3.0, 1.0, 1.0);
			for (int i = 1; i < 4; i++) {
				set_Appearance("woodwall", obj_shape_array[i], true);
			}
			set_Appearance("woodwall", obj_shape_array[9], true);
			// 4-7 (interior left walls)
			imageVec = new Vector3d(1.0, 1.0, 1.0);
			for (int i = 4; i < 8; i++) {
				set_Appearance("fancywall", obj_shape_array[i], true);
			}
			// 11-14 (interior right walls)
			for (int i = 11; i < 15; i++) {
				set_Appearance("fancywall", obj_shape_array[i], true);
			}
			set_Appearance("metal", obj_shape_array[10], false); // Lights
		} 
		//Repeat this process for each of the different objects that we use
		else if (obj_name.equals("Poster1")) {		//Ada Lovelace Poster
			set_Appearance("AdaLovelacePoster", obj_shape_array[0], false);
			set_Appearance("AdaLovelacePoster", obj_shape_array[1], false);
		} 
		//Special case for paintings, where we apply their textures depending on the given content and frame Strings
		else if (isPainting) {	
			set_Appearance(paintingContent, obj_shape_array[0], false);
			set_Appearance(paintingFrame, obj_shape_array[1], true);
		} else if (obj_name.equals("TuringMachine")) {		//Turing Machine, has a lot of parts that can be coloured/textured
			obj_shape_array[0].setAppearance(appearances.get(7));
			set_Appearance("DarkMarbleTexture", obj_shape_array[1], false);
			set_Appearance("beigeflr", obj_shape_array[2], false);
			set_Appearance("metal", obj_shape_array[3], false);
			set_Appearance("beigeflr", obj_shape_array[4], false);
			set_Appearance("metal", obj_shape_array[5], false);
			set_Appearance("glass", obj_shape_array[6], false);
			set_Appearance("metal", obj_shape_array[7], false);
			set_Appearance("metal", obj_shape_array[8], false);
			set_Appearance("metal", obj_shape_array[9], false);
			set_Appearance("metal", obj_shape_array[10], false);
			set_Appearance("PaintingFrame", obj_shape_array[11], false);
			set_Appearance("beigeflr", obj_shape_array[12], false);
			imageVec = new Vector3d(10.0, 10.0, 10.0);
			set_Appearance("PaintingFrame", obj_shape_array[13], true);
		}
		else if (obj_name.equals("door")) {	//Room Entrance Door
			for (Shape3D a : obj_shape_array) {
				set_Appearance("Door", a, false);
			}
			set_Appearance("Metal", obj_shape_array[1], false);
			set_Appearance("Metal", obj_shape_array[3], false);
		} 
		else if (obj_name.equals("plinth1")) {		//Flat Plinth
			set_Appearance("wood", obj_shape_array[0], false);
			set_Appearance("fancywall", obj_shape_array[1], false);
		} 
		else if (obj_name.equals("plint2")) {		//Slanted Plinth
			set_Appearance("wood", obj_shape_array[0], false);
		} 
		else if (obj_name.equals("Fan")) {			//Cieling Fan
			set_Appearance("wood", obj_shape_array[0], false);
			set_Appearance("wood", obj_shape_array[1], false);
			set_Appearance("metal", obj_shape_array[2], false);
			obj_shape_array[3].setAppearance(appearances.get(4));
			obj_shape_array[4].setAppearance(appearances.get(6));

		} 
		else if (obj_name.equals("BestPlant")) {	//Room Corner Plants
			//Theres a lot of objects in this model, so initializing all of the textures can slow it down somewhat

			set_Appearance("branch", obj_shape_array[0], false); // Stem
			// for (int i = 1; i < 23; i++) {	//This will texture the leaves properly but will be slower
			// 	set_Appearance("leaf", obj_shape_array[i], false);	//Leaves
			// }
			for (int i = 1; i < 23; i++) {
				obj_shape_array[i].setAppearance(appearances.get(10));	//Leaves
			}	
			set_Appearance("Ceramic", obj_shape_array[4], false); // Pot
			obj_shape_array[5].setAppearance(appearances.get(9)); // Dirt

		}
		else if (obj_name.equals("EvlofComp3")) {	//Evolution of computers desk and computers
			// Assign colors for the first 10 parts explicitly
			if (obj_shape_array.length > 0)
				obj_shape_array[0].setAppearance(appearances.get(5));
			if (obj_shape_array.length > 1)
				obj_shape_array[1].setAppearance(appearances.get(0));
			if (obj_shape_array.length > 2)
				obj_shape_array[2].setAppearance(appearances.get(1));
			for (int i = 3; i <= 15 && i < obj_shape_array.length; i++) {
				obj_shape_array[i].setAppearance(appearances.get(5)); // Black
				if (i == 10 | i == 9 | i == 11 | i == 12) {
					obj_shape_array[i].setAppearance(appearances.get(2));
				}
			}
			for (int i = 16; i < obj_shape_array.length; i++) {
				obj_shape_array[i].setAppearance(appearances.get(2)); // Dark Grey
			}
		} 
		else if (obj_name.equals("rtable")) {	//Table for Storage Devices
			// Apply to all parts of the table
			imageVec = new Vector3d(1.0,1.0,1.0);
			for (int i = 0; i < obj_shape_array.length; i++) {
				set_Appearance("wood", obj_shape_array[i], false);
			}
		} else if (obj_name.equals("CD")) {	//CD Disk
			obj_shape_array[0].setAppearance(appearances.get(6));
		} else if (obj_name.equals("floppydisk1")) {	//Floppy Disk
			obj_shape_array[0].setAppearance(appearances.get(3));
			obj_shape_array[1].setAppearance(appearances.get(8));
			obj_shape_array[2].setAppearance(appearances.get(5));
		} else if (obj_name.equals("USB")) {	//USB
			obj_shape_array[0].setAppearance(appearances.get(7));
			obj_shape_array[1].setAppearance(appearances.get(5));
			obj_shape_array[2].setAppearance(appearances.get(8));
		} else if (obj_name.equals("Tux")) {	//Tux, the Linux Penguin
			obj_shape_array[0].setAppearance(appearances.get(8)); // beak
			obj_shape_array[1].setAppearance(appearances.get(7)); // Belly
			obj_shape_array[2].setAppearance(appearances.get(5)); // Skin
			obj_shape_array[3].setAppearance(appearances.get(8)); // Right Foot
			obj_shape_array[4].setAppearance(appearances.get(8)); // Left Foot
			obj_shape_array[5].setAppearance(appearances.get(7)); // Eye
			obj_shape_array[6].setAppearance(appearances.get(5)); // Pupil
			obj_shape_array[7].setAppearance(appearances.get(7)); // Eye
			obj_shape_array[8].setAppearance(appearances.get(5)); // Pupil
		}

	}

	/**
	 * textured_App will load our image textures from our images folder
	 */
	protected static Texture textured_App(String name) {
		String filename = "images/" + name + ".jpg"; 				// obtain filename of the image in the image folder
		TextureLoader loader = new TextureLoader(filename, null);	// create texture loader with our filename
		ImageComponent2D image = loader.getImage(); 				// load the image as ImageComponent2D
		if (image == null) {
			System.out.println("Cannot load file: " + filename);	// if the image fails to load, print this
		}
		Texture2D texture = new Texture2D(Texture.BASE_LEVEL, Texture.RGBA, image.getWidth(), image.getHeight());	// create a texture from our loaded image
		texture.setImage(0, image); // set image for the texture

		return texture;		//Return our completed image texture
	}


	/**
	 * set_Appearance takes in a texturePath (path to an image), shape (part or whole object), and boolean designating if its repeating
	 * set_Appearance will create an image texture with the texturePath and apply it to the given shape
	 * it will either wrap the imag around the whole object or make it a repeating texture around the image (depending on the boolean)
	 */
	public static void set_Appearance(String texturePath, Shape3D shape, Boolean repeating) {
		Appearance app = new Appearance();	// Create a new Appearance object
		Texture texture = textured_App(texturePath); // Load the texture from the given path
		if (repeating) {	//If the boolean is set to be repeating
			//The texture will repeat across the object with this boundary mode
			texture.setBoundaryModeS(Texture.WRAP);
			texture.setBoundaryModeT(Texture.WRAP);
		} else {
			//The texture will stretch to fit the object with this boundary mode
			texture.setBoundaryModeS(Texture.CLAMP);
			texture.setBoundaryModeT(Texture.CLAMP);
		}
		app.setTexture(texture);	//Apply the texture with the given boundary mode to our appearance

		if (texturePath.equals("glass")) {		//Special case if the texture is glass
			TransparencyAttributes transparency = new TransparencyAttributes();	//Add transparency attributes
			transparency.setTransparencyMode(TransparencyAttributes.BLENDED);	//set transparency mode
			transparency.setTransparency(0.75f); // 75% transparency
			app.setTransparencyAttributes(transparency);	//apply glass-like transparency to the appearance/object part
		}

		// Retrieve the geometry of the provided Shape3D object
		Geometry geometry = shape.getGeometry();
		if (!(geometry instanceof GeometryArray)) {		//error checking in case the geometry is unusable
			System.err.println("Geometry is not a GeometryArray. Cannot apply texture.");
			return;
		}
		GeometryArray geometryArray = (GeometryArray) geometry;		//obtain the obtained geometry as a GeometryArray

		// Check if the geometry already has texture coordinates
		int texCoordSetCount = geometryArray.getTexCoordSetCount();		//Get the geometryArray's texture coordinates count
		if (texCoordSetCount == 0) {
			// Generate texture coordinates if not present
			TexCoordGeneration tcg = new TexCoordGeneration(TexCoordGeneration.OBJECT_LINEAR,TexCoordGeneration.TEXTURE_COORDINATE_2);
			app.setTexCoordGeneration(tcg);
		}

		// Configure texture attributes
		TextureAttributes textureAttrib = new TextureAttributes();	// Create texture attributes
		textureAttrib.setTextureMode(TextureAttributes.REPLACE); 	// Replace object color with texture
		app.setTextureAttributes(textureAttrib);		// Apply Texture Attributes

		// Apply texture transformation for repetition
		Transform3D transform = new Transform3D();
		if (repeating) {
			transform.setScale(imageVec); // Scale for texture repetition
		}
		textureAttrib.setTextureTransform(transform);	// Apply the transformation

		// Set the appearance to the shape
		shape.setAppearance(app);
	}

}

/**
 * MuseumObject class is where we build our museum objects, it extends BuildObjects and makes use of it's classes through inheritance.
 * MuseumObject implements BuildObjects' abstract classes position_Object and add_Child, and also has some of it's own
 */
class MuseumObject extends BuildObjects {

	//Constructor takes in our custom data type - ObjectData, which contains all of the needed data to build an object
	public MuseumObject(ObjectData objData) {
		//Save the data
		data = objData;
		//obtain the name, scaling, and translation data from our custom data type
		obj_name = objData.getObjectName();
		scale = objData.getScale();
		post = objData.getTranslation();

		//We can check which extra attributes we can initialize depending on what subclass of ObjectData it may be
		//Here, if it is paintingData, we can gain additional attributes regarding the frame and content images for the painting
		if (objData instanceof paintingData) {
			isPainting = true;	//Marks this object as a painting
			paintingData pd = (paintingData) objData;	//Cast to paintingData
			paintingContent = pd.getContent();	//Get the paintings content (ie. the picture that's displayed)
			paintingFrame = pd.getFrame();		//Get the paintings frame image (ie. the wood the frame is made of)
		}

		//Apply transformations with transform_Object (and also initialize it's obj_shape_array)
		transform_Object(obj_name);
		//Apply our desired appearance with obj_Appearance
		obj_Appearance();
	}

	//position_Object is inherited, and should be called after our constructor
	//position_Object will set our rotation, continuous rotations (if there are any) and will return our completed object's TransformGroup
	public TransformGroup position_Object() {
		// Data Should always be either positionData or rotatingPositionData
		if (!(data instanceof ObjectData)) {	//Checking if our input data is valid
			System.out.println("Invalid Input");
			return null;
		}

		if (data instanceof positionData posData) { // If it's positionData then we also perform a singular rotation
			rotation(posData.getRotations()); // Get Rotation using our given data
			objTG.addChild(objRG);	// Add rotation to object's TransformGroup (translation)
			objRG.addChild(objBG);	// Add object's BranchGroup (which will contain the object itself) to our rotation TransformGroup
		}

		if (data instanceof rotatingPositionData rotData) { // If it's rotatingPositionData then we also perform continuous rotation
			contRotation(rotData.getAlpha(), rotData.getAxis()); // Apply Repeating Rotations
		}

		return objTG;	//return our finished object TransformGroup
	}

	//contRotation sets up continuous rotation with a given alpha and axis
	//This uses our RotateObject class to make the object easily manipulated
	public void contRotation(Alpha alpha, char axis) {
		rotationAlpha = alpha;		//Save our alpha for later use
		isRotating = true;			//Designates object as a rotating object
		//Create a tranform3D, we'll need to reapply scaling and translation for this continuous rotation
		Transform3D scaler = new Transform3D();	
		scaler.setScale(scale);			//Apply scaling
		scaler.setTranslation(post);	//Apply translation
		//Initialize our MuseumObject's rotateObject with the given scaling, object TransformGroup, and axis
		rotateObject = new RotateObject(objTG, scaler, 0, axis);	
		rotateObject.setAlpha(rotationAlpha);	//change our rotateObject's alpha to the given alpha
		objTG = rotateObject.AddRotation();		//set our objTG to the TransformGroup given by rotateObject's AddRotation method
	}

	//rotation sets up a singular rotation for neatly placing the object in the Museum
	public TransformGroup rotation(double rotations[]) {	//rotations is obtained earlier from our custom data type
		// Perform rotations with Transform3D's
		Transform3D x_axis = new Transform3D();		//x-axis rotations
		Transform3D y_axis = new Transform3D();		//y-axis rotations
		Transform3D z_axis = new Transform3D();		//z-axis rotations
		x_axis.rotX(rotations[0]);		//Apply x-axis rotations
		y_axis.rotY(rotations[1]);		//Apply y-axis rotations
		z_axis.rotZ(rotations[2]);		//Apply z-axis rotations

		// Combine rotations
		x_axis.mul(y_axis);		// combine x and y
		x_axis.mul(z_axis);		// combine x and y and z

		return objRG = new TransformGroup(x_axis);	//set our object's rotation TransformGroup to a new TG defined by the rotations
	}

	//add_Child is inherited as well, and simply lets us add TGs to our current object TG
	public void add_Child(TransformGroup nextTG) {	//Takes in TG
		objTG.addChild(nextTG); // attach the next transformGroup to 'objTG'
	}

}

